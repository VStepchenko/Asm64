@echo off

set appname=HelloWorld
set binpath="bin\"
set libpath="lib"

del %appname%.obj
del %appname%.exe

%binpath%ml64.exe /c %appname%.asm

%binpath%link.exe user32.lib kernel32.lib /SUBSYSTEM:CONSOLE /MACHINE:X64 /ENTRY:main /nologo /LARGEADDRESSAWARE %appname%.obj /LIBPATH:%libpath%

pause