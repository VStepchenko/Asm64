simple "build script" to assemble the 64 helloworld example.
tested on Windows 10
just run makeit.bat